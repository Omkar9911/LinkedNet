import {User} from './user';

export class Role{
  name: string;
  users: Array<User>;

}
