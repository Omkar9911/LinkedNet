package com.linkedin.linkedinclone.recommendation;

public class Pair {
    int index;
    double value;

    public Pair(int index, double value){
        this.index = index;
        this.value = value;
    }
}
