package com.linkedin.linkedinclone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LinkedinCloneApplicationTests {

	@Test
	void contextLoads() {
	}

}
